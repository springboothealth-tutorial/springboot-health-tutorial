const menuList = [
    {
        title: '首页',
        key: '/home'
    },

    {
        title: '用户管理',
        key: '/user'
    },
    {
        title: '食品管理',
        key: '/food'
    },
    {
        title: '运动管理',
        key: '/sport'
    }
];
export default menuList;