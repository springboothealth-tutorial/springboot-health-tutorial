import React from 'react'
import './index.less'
export default class Home extends React.Component{

    render(){
        return (
            <div className="home-wrap">
                欢迎来到健康管理系统
            </div>
        );
    }
}